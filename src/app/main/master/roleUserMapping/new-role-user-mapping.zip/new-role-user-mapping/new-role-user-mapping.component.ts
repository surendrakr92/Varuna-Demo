import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { roleUserMapping, roleUserMaster } from 'src/app/models/master';
import { CommonServiceService } from 'src/app/services/commonService/common-service.service';
import { CountryMasterService } from 'src/app/services/master-service/country-master.service';

@Component({
  selector: 'app-new-role-user-mapping',
  templateUrl: './new-role-user-mapping.component.html',
  styleUrls: ['./new-role-user-mapping.component.scss']
})
export class NewRoleUserMappingComponent {

  constructor(private formbuilder: FormBuilder,
    private masterservice: CountryMasterService,
    private toastrService: ToastrService,
    private routes: Router, private cs: CommonServiceService,//for id
    private router: ActivatedRoute) {
    this.UserId = this.cs.login_User_Code()//for id
  }
  UserId: any
  formRoleUserMapping!: FormGroup;
  submitted!: true
  filteredUsers: any = []
  roleMasterList: any = []
  roleUserMappingDetailsById: any = ""
  UserMasterList: any = []
  ngOnInit(): void {
    this.formRoleUserMapping = this.formbuilder.group({
      roleId: ['', Validators.required],
      userId: ['', Validators.required],
      defaultRole: ['', [Validators.required, Validators.pattern('^(?! )[0-9]{2,}(?: [s0-9]+)*$')]],
      isActive: [true]

    })
    this.getRoleMasterList()
    this.getUserMaster()
    this.router.params.subscribe((res) => {

      let roleUserMappingId = res.data
      if (roleUserMappingId) {
        this.masterservice.getRoleUserMappingById(roleUserMappingId).subscribe((res: any) => {
          this.roleUserMappingDetailsById = res.data
          this.formRoleUserMapping.patchValue(res.data)
        })
      }
    })
  }
  get f() {
    return this.formRoleUserMapping.controls;
  }
  getRoleMasterList() {
    this.masterservice.getAllRoleMasterList().subscribe((res: any) => {
      this.roleMasterList = res.data
    })
  }
  getUserMaster() {
    this.masterservice.getAllUserMasterList().subscribe((res: any) => {
      this.UserMasterList = res.data
    })
  }

  onSubmit() {
    this.submitted = true;
    if (this.formRoleUserMapping.invalid) {
      return
    }
    var roleUserMappingJson = new roleUserMapping
    roleUserMappingJson = this.formRoleUserMapping.value
    if (this.roleUserMappingDetailsById.mappingId == undefined) { roleUserMappingJson.createdBy = +this.UserId }
    else { roleUserMappingJson.updatedBy = +this.UserId; roleUserMappingJson.mappingId = this.roleUserMappingDetailsById.mappingId }

    console.log(roleUserMappingJson)
    if (this.roleUserMappingDetailsById == "") {
      this.masterservice.createRoleUserMapping(roleUserMappingJson).subscribe((result) => {

        this.toastrService.success('succesfully Created !', 'Success-200 !');
        this.routes.navigate(['master/role-user-mapping']);
      }, err => {
        if (err instanceof HttpErrorResponse) {
          if (err.status === 422) {
            debugger

            Object.keys(err.error.Errors).forEach((prop: any) => {
              const formControl = this.formRoleUserMapping.get(err.error.Errors[prop]?.PropertyName);
              //wrong key comes 
              if (formControl) {
                // activate the error message
                formControl.setErrors({
                  serverError: err.error.Errors[prop]?.ErrorMessage
                });
              }
            });

          }
          this.toastrService.error('some thing went wrong', 'Error !');
        }
      })

    } else {
      this.masterservice.editRoleUserMapping(roleUserMappingJson).subscribe((result) => {

        this.toastrService.success('succesfully Updated !', 'Success-200 !');
        this.routes.navigate(['master/role-user-mapping']);
      }, err => {
        if (err instanceof HttpErrorResponse) {
          if (err.status === 422) {
            debugger

            Object.keys(err.error.Errors).forEach((prop: any) => {
              const formControl = this.formRoleUserMapping.get(err.error.Errors[prop]?.PropertyName);
              //wrong key comes 
              if (formControl) {
                // activate the error message
                formControl.setErrors({
                  serverError: err.error.Errors[prop]?.ErrorMessage
                });
              }
            });

          }
          this.toastrService.error('some thing went wrong', 'Error !');
        }
      })
    }

  }
  filter(data: any) {
    this.filteredUsers = [...this.roleMasterList.filter((user: any) => user.roleName.includes(data.target.value))];
    console.log(this.filteredUsers)
  }
}